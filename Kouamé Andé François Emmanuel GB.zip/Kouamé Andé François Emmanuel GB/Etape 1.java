import java.util.HashMap;
import java.util.Map;

public class Automate {
    
    enum Etat {
        INIT, CARTE_VALIDEE, CODE_VALIDEE, ACCES_ACCORDE, ALARME
    }

    private Etat etatActuel;
    private final Map<String, Etat>transitions;

    public Automate() {
        
        etatActuel = Etat.INIT;

        transitions = new HashMap<>();
        transitions.put("INIT:carteValide", Etat.CARTE_VALIDEE);
        transitions.put("CARTE_VALIDEE:codeCorrect", Etat.ACCES_ACCORDE);
        transitions.put("CARTE_VALIDEE:codeIncorrect", Etat.ALARME);
        transitions.put("INIT:carteInvalide", Etat.ALARME);
    }

    public void traiterEntree(String entree) {
        String cle = etatActuel + ":" + entree;
        if (transitions.containsKey(cle)) {
            etatActuel = transitions.get(cle);
            System.out.println("Transition vers l'etat : " + etatActuel);
        } else {
            System.out.println("Entree invalide : reste dans l'etat " + etatActuel);
        }
    }

    public Etat getEtatActuel() {
        return etatActuel;
    }

    public static void main(String[] args) {
        Automate automate = new Automate();

        automate.traiterEntree("carteValide");
        automate.traiterEntree("codeCorrect");
        System.out.println("Etat final : " + automate.getEtatActuel());
    }
}
         