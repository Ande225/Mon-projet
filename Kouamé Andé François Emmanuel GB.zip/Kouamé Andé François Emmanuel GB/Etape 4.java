public class VerificationFormelle {
    public static boolean verifierRegles(boolean carteValide, boolean codeCorrect) {
        boolean accesAccorde = carteValide && codeCorrect;
        boolean alarme = !carteValide || (carteValide && !codeCorrect);

        return !(accesAccorde && alarme);
    }

    public static void main(String[] args) {
        boolean[] cartes = {true, false};
        boolean[] codes = {true, false};

        for (boolean carteValide : cartes) {
            for (boolean codeCorrect : codes) {
                boolean reglesRespectees = verifierRegles(carteValide, codeCorrect);
                System.out.printf("Carte valide: %b, Code correct: %b -> Regles respectees: %b%n",
                        carteValide, codeCorrect, reglesRespectees);
            }
        }
    }
}