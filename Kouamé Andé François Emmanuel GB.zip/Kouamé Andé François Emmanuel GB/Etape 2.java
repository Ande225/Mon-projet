import java.util.regex.Pattern;

public class VerificateurSequences {
    private static final String SEQUENCE_VALIDE = "carteValide:(codeCorrect|codeIncorrect)";

    public static void verifierSequence(String sequence) {
        if (Pattern.matches(SEQUENCE_VALIDE, sequence)) {
            System.out.println("Sequence valide : " + sequence);
        } else {
            System.out.println("Sequence invalide : " + sequence);
        }
    }

    public static void main(String[] args) {
        verifierSequence("carteValide:codeCorrect");
        verifierSequence("carteValide:codeIncorrect");
        verifierSequence("carteInvalide:codeCorrect");
    }
}