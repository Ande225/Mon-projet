public class CircuitsLogiques {
    public static boolean verifierAcces(boolean carteValide, boolean codeCorrect) {
        return carteValide && codeCorrect;
    }
    public static boolean verifierAlarme(boolean carteValide, boolean codeCorrect) {
        return !carteValide || (carteValide && !codeCorrect);
    }

    public static void main(String[] args) {
        boolean carteValide = true;
        boolean codeCorrect = false;

        System.out.println("Acces accorde : " + verifierAcces(carteValide, codeCorrect));
        System.out.println("Alarme activee : " + verifierAlarme(carteValide, codeCorrect));
    }
}